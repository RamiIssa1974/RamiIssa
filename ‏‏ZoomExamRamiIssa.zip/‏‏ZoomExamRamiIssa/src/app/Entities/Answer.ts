export interface IAnswer {
    text: string;
    isRight: boolean;
    isAnsweredRight : boolean;
    isSelected : boolean;
}